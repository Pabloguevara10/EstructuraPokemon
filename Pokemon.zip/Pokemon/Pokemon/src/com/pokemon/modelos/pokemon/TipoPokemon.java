package com.pokemon.modelos.pokemon;

import java.io.Serializable;

public enum TipoPokemon implements Serializable {
    AGUA, FUEGO, PLANTA, ELECTRICO, NORMAL;
}
