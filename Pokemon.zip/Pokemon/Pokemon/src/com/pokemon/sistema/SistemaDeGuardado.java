package com.pokemon.sistema;

import com.pokemon.estructuras.ArbolAVL;
import com.pokemon.estructuras.ArbolBinarioBusqueda;
import java.io.*;

public class SistemaDeGuardado {

    private static final String ARCHIVO_BST = "registro_historico.dat";
    private static final String ARCHIVO_AVL = "ranking_liga.dat";
    private static final String ARCHIVO_ID = "proximo_id.dat";

    public void guardarDatos(ArbolBinarioBusqueda<?> bst, ArbolAVL<?> avl, int proximoId) {
        try (ObjectOutputStream oosBst = new ObjectOutputStream(new FileOutputStream(ARCHIVO_BST));
             ObjectOutputStream oosAvl = new ObjectOutputStream(new FileOutputStream(ARCHIVO_AVL));
             DataOutputStream dosId = new DataOutputStream(new FileOutputStream(ARCHIVO_ID))) {

            oosBst.writeObject(bst);
            oosAvl.writeObject(avl);
            dosId.writeInt(proximoId);
            System.out.println("¡Datos guardados exitosamente!");

        } catch (IOException e) {
            System.err.println("Error al guardar los datos: " + e.getMessage());
        }
    }
    
    @SuppressWarnings("unchecked")
    public Object[] cargarDatos() {
        File fbst = new File(ARCHIVO_BST);
        if (!fbst.exists()) {
            System.out.println("No se encontraron datos guardados. Empezando una nueva partida.");
            return null;
        }

        try (ObjectInputStream oisBst = new ObjectInputStream(new FileInputStream(ARCHIVO_BST));
             ObjectInputStream oisAvl = new ObjectInputStream(new FileInputStream(ARCHIVO_AVL));
             DataInputStream disId = new DataInputStream(new FileInputStream(ARCHIVO_ID))) {

            ArbolBinarioBusqueda<?> bst = (ArbolBinarioBusqueda<?>) oisBst.readObject();
            ArbolAVL<?> avl = (ArbolAVL<?>) oisAvl.readObject();
            int proximoId = disId.readInt();
            System.out.println("¡Datos cargados exitosamente!");
            
            return new Object[]{bst, avl, proximoId};

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error al cargar los datos, se empezará una nueva partida: " + e.getMessage());
            return null;
        }
    }
}
